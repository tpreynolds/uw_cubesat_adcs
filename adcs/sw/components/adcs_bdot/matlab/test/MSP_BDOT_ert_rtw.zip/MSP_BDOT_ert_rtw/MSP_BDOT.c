/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: MSP_BDOT.c
 *
 * Code generated for Simulink model 'MSP_BDOT'.
 *
 * Model version                  : 1.324
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Wed Mar  7 18:04:30 2018
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->MSP430
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#include "MSP_BDOT.h"

/* Block signals and states (auto storage) */
DW rtDW;

/* External inputs (root inport signals with auto storage) */
ExtU rtU;

/* External outputs (root outports fed by signals with auto storage) */
ExtY rtY;

/* Real-time model */
RT_MODEL rtM_;
RT_MODEL *const rtM = &rtM_;

/* Model step function for TID0 */
void MSP_BDOT_step0(void)              /* Sample time: [0.05s, 0.0s] */
{
  /* Update the flag to indicate when data transfers from
   *  Sample time: [0.05s, 0.0s] to Sample time: [0.1s, 0.0s]  */
  (rtM->Timing.RateInteraction.TID0_1)++;
  if ((rtM->Timing.RateInteraction.TID0_1) > 1) {
    rtM->Timing.RateInteraction.TID0_1 = 0;
  }

  /* RateTransition: '<S2>/Rate Transition1' */
  if (rtM->Timing.RateInteraction.TID0_1 == 1) {
    /* Outport: '<Root>/cmd_MAG_bdot' */
    rtY.cmd_MAG_bdot[0] = rtDW.RateTransition1_Buffer0[0];
    rtY.cmd_MAG_bdot[1] = rtDW.RateTransition1_Buffer0[1];
    rtY.cmd_MAG_bdot[2] = rtDW.RateTransition1_Buffer0[2];
  }

  /* End of RateTransition: '<S2>/Rate Transition1' */

  /* RateTransition: '<S2>/Rate Transition2' incorporates:
   *  Inport: '<Root>/mag_body_T_unprocessed'
   */
  if (!(rtDW.RateTransition2_semaphoreTaken != 0)) {
    rtDW.RateTransition2_Buffer0 = rtU.mag_vec_body_T[3];
  }

  /* End of RateTransition: '<S2>/Rate Transition2' */

  /* RateTransition: '<S2>/Rate Transition4' incorporates:
   *  Inport: '<Root>/mag_body_T_unprocessed'
   */
  if (!(rtDW.RateTransition4_semaphoreTaken != 0)) {
    rtDW.RateTransition4_Buffer0[0] = rtU.mag_vec_body_T[0];
    rtDW.RateTransition4_Buffer0[1] = rtU.mag_vec_body_T[1];
    rtDW.RateTransition4_Buffer0[2] = rtU.mag_vec_body_T[2];
  }

  /* End of RateTransition: '<S2>/Rate Transition4' */
}

/* Model step function for TID1 */
void MSP_BDOT_step1(void)              /* Sample time: [0.1s, 0.0s] */
{
  boolean_T rtb_LogicalOperator1;
  real_T rtb_RateTransition2;
  real_T rtb_Sum[3];
  int8_T rtb_DataTypeConversion[3];
  real_T rtb_RateTransition4[3];
  real_T rtb_Product[3];
  int16_T i;
  real_T rtb_TSamp_idx_0;
  real_T rtb_TSamp_idx_1;
  real_T rtb_TSamp_idx_2;
  real_T rtb_MultiportSwitch1_idx_0;
  real_T rtb_MultiportSwitch1_idx_1;
  real_T rtb_MultiportSwitch1_idx_2;
  real_T rtb_Product_0;

  /* Logic: '<S2>/Logical Operator1' incorporates:
   *  RateTransition: '<S2>/Rate Transition3'
   */
  rtb_LogicalOperator1 =
    !(rtDW.RateTransition3_Buffer[rtDW.RateTransition3_ActiveBufIdx] != 0.0);

  /* RateTransition: '<S2>/Rate Transition2' */
  rtDW.RateTransition2_semaphoreTaken = 1;
  rtb_RateTransition2 = rtDW.RateTransition2_Buffer0;
  rtDW.RateTransition2_semaphoreTaken = 0;

  /* SampleTimeMath: '<S3>/TSamp' incorporates:
   *  DiscreteTransferFcn: '<S2>/Discrete Transfer Fcn'
   *
   * About '<S3>/TSamp':
   *  y = u * K where K = 1 / ( w * Ts )
   */
  rtb_TSamp_idx_0 = 0.060898632575707344 * rtDW.DiscreteTransferFcn_states[0L] *
    10.0;
  rtb_TSamp_idx_1 = 0.060898632575707344 * rtDW.DiscreteTransferFcn_states[1L] *
    10.0;
  rtb_TSamp_idx_2 = 0.060898632575707344 * rtDW.DiscreteTransferFcn_states[2L] *
    10.0;

  /* MultiPortSwitch: '<S2>/Multiport Switch1' incorporates:
   *  Logic: '<S2>/Logical Operator'
   *  Sum: '<S3>/Diff'
   *  UnitDelay: '<S2>/Unit Delay'
   *  UnitDelay: '<S3>/UD'
   *
   * Block description for '<S3>/Diff':
   *
   *  Add in CPU
   *
   * Block description for '<S3>/UD':
   *
   *  Store in Global RAM
   */
  if (!(rtb_LogicalOperator1 && (rtb_RateTransition2 != 0.0))) {
    rtb_MultiportSwitch1_idx_0 = rtDW.UnitDelay_DSTATE[0];
    rtb_MultiportSwitch1_idx_1 = rtDW.UnitDelay_DSTATE[1];
    rtb_MultiportSwitch1_idx_2 = rtDW.UnitDelay_DSTATE[2];
  } else {
    rtb_MultiportSwitch1_idx_0 = rtb_TSamp_idx_0 - rtDW.UD_DSTATE[0];
    rtb_MultiportSwitch1_idx_1 = rtb_TSamp_idx_1 - rtDW.UD_DSTATE[1];
    rtb_MultiportSwitch1_idx_2 = rtb_TSamp_idx_2 - rtDW.UD_DSTATE[2];
  }

  /* End of MultiPortSwitch: '<S2>/Multiport Switch1' */

  /* MultiPortSwitch: '<S2>/Multiport Switch2' incorporates:
   *  Gain: '<S2>/To DigVal1'
   *  Gain: '<S2>/To DigVal2'
   *  Gain: '<S2>/To DigVal3'
   */
  if (!rtb_LogicalOperator1) {
    rtb_Sum[0] = 0.0;
    rtb_Sum[1] = 0.0;
    rtb_Sum[2] = 0.0;
  } else {
    /* Product: '<S2>/Product' incorporates:
     *  Constant: '<S2>/gain matrix'
     */
    for (i = 0; i < 3; i++) {
      rtb_Product[i] = rtConstP.gainmatrix_Value[i + 6] *
        rtb_MultiportSwitch1_idx_2 + (rtConstP.gainmatrix_Value[i + 3] *
        rtb_MultiportSwitch1_idx_1 + rtConstP.gainmatrix_Value[i] *
        rtb_MultiportSwitch1_idx_0);
    }

    /* End of Product: '<S2>/Product' */

    /* Saturate: '<S2>/Saturation1' */
    if (rtb_Product[0] > 0.15) {
      rtb_Product_0 = 0.15;
    } else if (rtb_Product[0] < -0.15) {
      rtb_Product_0 = -0.15;
    } else {
      rtb_Product_0 = rtb_Product[0];
    }

    /* End of Saturate: '<S2>/Saturation1' */
    rtb_Sum[0] = 846.66666666666663 * rtb_Product_0;

    /* Saturate: '<S2>/Saturation2' incorporates:
     *  Gain: '<S2>/To DigVal1'
     */
    if (rtb_Product[1] > 0.15) {
      rtb_Product_0 = 0.15;
    } else if (rtb_Product[1] < -0.15) {
      rtb_Product_0 = -0.15;
    } else {
      rtb_Product_0 = rtb_Product[1];
    }

    /* End of Saturate: '<S2>/Saturation2' */
    rtb_Sum[1] = 846.66666666666663 * rtb_Product_0;

    /* Saturate: '<S2>/Saturation3' incorporates:
     *  Gain: '<S2>/To DigVal2'
     */
    if (rtb_Product[2] > 0.15) {
      rtb_Product_0 = 0.15;
    } else if (rtb_Product[2] < -0.15) {
      rtb_Product_0 = -0.15;
    } else {
      rtb_Product_0 = rtb_Product[2];
    }

    /* End of Saturate: '<S2>/Saturation3' */
    rtb_Sum[2] = 846.66666666666663 * rtb_Product_0;
  }

  /* End of MultiPortSwitch: '<S2>/Multiport Switch2' */

  /* DataTypeConversion: '<S2>/Data Type Conversion' */
  rtb_Product_0 = fabs(rtb_Sum[0]);
  if (rtb_Product_0 < 4.503599627370496E+15) {
    if (rtb_Product_0 >= 0.5) {
      rtb_DataTypeConversion[0] = (int8_T)floor(rtb_Sum[0] + 0.5);
    } else {
      rtb_DataTypeConversion[0] = (int8_T)(rtb_Sum[0] * 0.0);
    }
  } else {
    rtb_DataTypeConversion[0] = (int8_T)rtb_Sum[0];
  }

  rtb_Product_0 = fabs(rtb_Sum[1]);
  if (rtb_Product_0 < 4.503599627370496E+15) {
    if (rtb_Product_0 >= 0.5) {
      rtb_DataTypeConversion[1] = (int8_T)floor(rtb_Sum[1] + 0.5);
    } else {
      rtb_DataTypeConversion[1] = (int8_T)(rtb_Sum[1] * 0.0);
    }
  } else {
    rtb_DataTypeConversion[1] = (int8_T)rtb_Sum[1];
  }

  rtb_Product_0 = fabs(rtb_Sum[2]);
  if (rtb_Product_0 < 4.503599627370496E+15) {
    if (rtb_Product_0 >= 0.5) {
      rtb_DataTypeConversion[2] = (int8_T)floor(rtb_Sum[2] + 0.5);
    } else {
      rtb_DataTypeConversion[2] = (int8_T)(rtb_Sum[2] * 0.0);
    }
  } else {
    rtb_DataTypeConversion[2] = (int8_T)rtb_Sum[2];
  }

  /* End of DataTypeConversion: '<S2>/Data Type Conversion' */

  /* RateTransition: '<S2>/Rate Transition4' */
  rtDW.RateTransition4_semaphoreTaken = 1;
  rtb_RateTransition4[0] = rtDW.RateTransition4_Buffer0[0];
  rtb_RateTransition4[1] = rtDW.RateTransition4_Buffer0[1];
  rtb_RateTransition4[2] = rtDW.RateTransition4_Buffer0[2];
  rtDW.RateTransition4_semaphoreTaken = 0;
  for (i = 0; i < 3; i++) {
    /* Update for RateTransition: '<S2>/Rate Transition1' */
    rtDW.RateTransition1_Buffer0[i] = rtb_DataTypeConversion[i];

    /* Product: '<S4>/Product' incorporates:
     *  Constant: '<S4>/Constant1'
     *  Sum: '<S4>/Sum'
     */
    rtb_Sum[i] = rtConstP.Constant1_Value[i + 6] * rtb_RateTransition4[2] +
      (rtConstP.Constant1_Value[i + 3] * rtb_RateTransition4[1] +
       rtConstP.Constant1_Value[i] * rtb_RateTransition4[0]);
  }

  /* Update for UnitDelay: '<S2>/Unit Delay' incorporates:
   *  DiscreteTransferFcn: '<S2>/Discrete Transfer Fcn'
   *  Update for DiscreteTransferFcn: '<S2>/Discrete Transfer Fcn'
   */
  rtDW.UnitDelay_DSTATE[0] = rtb_MultiportSwitch1_idx_0;

  /* Update for DiscreteTransferFcn: '<S2>/Discrete Transfer Fcn' */
  rtDW.DiscreteTransferFcn_states[0L] = rtb_Sum[0L] - -0.93910136742429262 *
    rtDW.DiscreteTransferFcn_states[0L];

  /* Update for UnitDelay: '<S3>/UD' incorporates:
   *  DiscreteTransferFcn: '<S2>/Discrete Transfer Fcn'
   *  Update for DiscreteTransferFcn: '<S2>/Discrete Transfer Fcn'
   *
   * Block description for '<S3>/UD':
   *
   *  Store in Global RAM
   */
  rtDW.UD_DSTATE[0] = rtb_TSamp_idx_0;

  /* Update for UnitDelay: '<S2>/Unit Delay' incorporates:
   *  DiscreteTransferFcn: '<S2>/Discrete Transfer Fcn'
   *  Update for DiscreteTransferFcn: '<S2>/Discrete Transfer Fcn'
   */
  rtDW.UnitDelay_DSTATE[1] = rtb_MultiportSwitch1_idx_1;

  /* Update for DiscreteTransferFcn: '<S2>/Discrete Transfer Fcn' */
  rtDW.DiscreteTransferFcn_states[1L] = rtb_Sum[1L] - -0.93910136742429262 *
    rtDW.DiscreteTransferFcn_states[1L];

  /* Update for UnitDelay: '<S3>/UD' incorporates:
   *  DiscreteTransferFcn: '<S2>/Discrete Transfer Fcn'
   *  Update for DiscreteTransferFcn: '<S2>/Discrete Transfer Fcn'
   *
   * Block description for '<S3>/UD':
   *
   *  Store in Global RAM
   */
  rtDW.UD_DSTATE[1] = rtb_TSamp_idx_1;

  /* Update for UnitDelay: '<S2>/Unit Delay' incorporates:
   *  DiscreteTransferFcn: '<S2>/Discrete Transfer Fcn'
   *  Update for DiscreteTransferFcn: '<S2>/Discrete Transfer Fcn'
   */
  rtDW.UnitDelay_DSTATE[2] = rtb_MultiportSwitch1_idx_2;

  /* Update for DiscreteTransferFcn: '<S2>/Discrete Transfer Fcn' */
  rtDW.DiscreteTransferFcn_states[2L] = rtb_Sum[2L] - -0.93910136742429262 *
    rtDW.DiscreteTransferFcn_states[2L];

  /* Update for UnitDelay: '<S3>/UD' incorporates:
   *  DiscreteTransferFcn: '<S2>/Discrete Transfer Fcn'
   *  Update for DiscreteTransferFcn: '<S2>/Discrete Transfer Fcn'
   *
   * Block description for '<S3>/UD':
   *
   *  Store in Global RAM
   */
  rtDW.UD_DSTATE[2] = rtb_TSamp_idx_2;
}

/* Model step function for TID2 */
void MSP_BDOT_step2(void)              /* Sample time: [0.5s, 0.0s] */
{
  int16_T rtb_PulseGenerator;

  /* DiscretePulseGenerator: '<S1>/Pulse Generator' */
  rtb_PulseGenerator = ((rtDW.clockTickCounter < 1L) && (rtDW.clockTickCounter >=
    0L));
  if (rtDW.clockTickCounter >= 1L) {
    rtDW.clockTickCounter = 0L;
  } else {
    rtDW.clockTickCounter++;
  }

  /* End of DiscretePulseGenerator: '<S1>/Pulse Generator' */

  /* Update for RateTransition: '<S2>/Rate Transition3' */
  rtDW.RateTransition3_Buffer[rtDW.RateTransition3_ActiveBufIdx == 0] =
    rtb_PulseGenerator;
  rtDW.RateTransition3_ActiveBufIdx = (int8_T)(rtDW.RateTransition3_ActiveBufIdx
    == 0);
}

/* Model initialize function */
void MSP_BDOT_initialize(void)
{
  /* (no initialization code required) */
}

/* Model terminate function */
void MSP_BDOT_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
