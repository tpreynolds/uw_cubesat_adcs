function CodeMetrics() {
	 this.metricsArray = {};
	 this.metricsArray.var = new Array();
	 this.metricsArray.fcn = new Array();
	 this.metricsArray.var["rtDW"] = {file: "/Users/Taylor/uw_cubesat_adcs_sourcetree/adcs/sw/components/adcs_bdot/matlab/test/MSP_BDOT_ert_rtw/MSP_BDOT.c",
	size: 130};
	 this.metricsArray.var["rtM_"] = {file: "/Users/Taylor/uw_cubesat_adcs_sourcetree/adcs/sw/components/adcs_bdot/matlab/test/MSP_BDOT_ert_rtw/MSP_BDOT.c",
	size: 3};
	 this.metricsArray.var["rtU"] = {file: "/Users/Taylor/uw_cubesat_adcs_sourcetree/adcs/sw/components/adcs_bdot/matlab/test/MSP_BDOT_ert_rtw/MSP_BDOT.c",
	size: 32};
	 this.metricsArray.var["rtY"] = {file: "/Users/Taylor/uw_cubesat_adcs_sourcetree/adcs/sw/components/adcs_bdot/matlab/test/MSP_BDOT_ert_rtw/MSP_BDOT.c",
	size: 3};
	 this.metricsArray.fcn["MSP_BDOT_initialize"] = {file: "/Users/Taylor/uw_cubesat_adcs_sourcetree/adcs/sw/components/adcs_bdot/matlab/test/MSP_BDOT_ert_rtw/MSP_BDOT.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["MSP_BDOT_step0"] = {file: "/Users/Taylor/uw_cubesat_adcs_sourcetree/adcs/sw/components/adcs_bdot/matlab/test/MSP_BDOT_ert_rtw/MSP_BDOT.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["MSP_BDOT_step1"] = {file: "/Users/Taylor/uw_cubesat_adcs_sourcetree/adcs/sw/components/adcs_bdot/matlab/test/MSP_BDOT_ert_rtw/MSP_BDOT.c",
	stack: 142,
	stackTotal: 142};
	 this.metricsArray.fcn["MSP_BDOT_step2"] = {file: "/Users/Taylor/uw_cubesat_adcs_sourcetree/adcs/sw/components/adcs_bdot/matlab/test/MSP_BDOT_ert_rtw/MSP_BDOT.c",
	stack: 2,
	stackTotal: 2};
	 this.metricsArray.fcn["MSP_BDOT_terminate"] = {file: "/Users/Taylor/uw_cubesat_adcs_sourcetree/adcs/sw/components/adcs_bdot/matlab/test/MSP_BDOT_ert_rtw/MSP_BDOT.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fabs"] = {file: "/Applications/MATLAB_R2016b.app/sys/lcc/include/math.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["floor"] = {file: "/Applications/MATLAB_R2016b.app/sys/lcc/include/math.h",
	stack: 0,
	stackTotal: 0};
	 this.getMetrics = function(token) { 
		 var data;
		 data = this.metricsArray.var[token];
		 if (!data) {
			 data = this.metricsArray.fcn[token];
			 if (data) data.type = "fcn";
		 } else { 
			 data.type = "var";
		 }
	 return data;}
}
	 CodeMetrics.instance = new CodeMetrics();
