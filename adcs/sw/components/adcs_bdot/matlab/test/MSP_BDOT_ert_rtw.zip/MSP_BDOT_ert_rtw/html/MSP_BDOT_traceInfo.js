function RTW_Sid2UrlHash() {
	this.urlHashMap = new Array();
	/* <S1>/Pulse
Generator */
	this.urlHashMap["adcs_sim_main:42:277:6"] = "MSP_BDOT.c:332,341&MSP_BDOT.h:52";
	/* <S2>/Constant */
	this.urlHashMap["adcs_sim_main:42:277:5:47"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:277:5:47";
	/* <S2>/Data Type Conversion */
	this.urlHashMap["adcs_sim_main:42:277:5:80"] = "MSP_BDOT.c:211,245";
	/* <S2>/Discrete
Transfer Fcn */
	this.urlHashMap["adcs_sim_main:42:277:5:32"] = "MSP_BDOT.c:108,267,268,272,277,278,287,288,292,297,298,307,308,312,317,318&MSP_BDOT.h:47";
	/* <S2>/Logical
Operator */
	this.urlHashMap["adcs_sim_main:42:277:5:28"] = "MSP_BDOT.c:121";
	/* <S2>/Logical
Operator1 */
	this.urlHashMap["adcs_sim_main:42:277:5:42"] = "MSP_BDOT.c:96";
	/* <S2>/Multiport
Switch1 */
	this.urlHashMap["adcs_sim_main:42:277:5:33"] = "MSP_BDOT.c:120,144";
	/* <S2>/Multiport
Switch2 */
	this.urlHashMap["adcs_sim_main:42:277:5:46"] = "MSP_BDOT.c:146,209";
	/* <S2>/Product */
	this.urlHashMap["adcs_sim_main:42:277:5:60"] = "MSP_BDOT.c:156,166";
	/* <S2>/Rate Transition1 */
	this.urlHashMap["adcs_sim_main:42:277:5:6"] = "MSP_BDOT.c:47,55,254&MSP_BDOT.h:53";
	/* <S2>/Rate Transition2 */
	this.urlHashMap["adcs_sim_main:42:277:5:29"] = "MSP_BDOT.c:57,64,102&MSP_BDOT.h:51,55";
	/* <S2>/Rate Transition3 */
	this.urlHashMap["adcs_sim_main:42:277:5:30"] = "MSP_BDOT.c:97,343&MSP_BDOT.h:49,54";
	/* <S2>/Rate Transition4 */
	this.urlHashMap["adcs_sim_main:42:277:5:7"] = "MSP_BDOT.c:66,75,247&MSP_BDOT.h:50,56";
	/* <S2>/Saturation1 */
	this.urlHashMap["adcs_sim_main:42:277:5:61"] = "MSP_BDOT.c:168,177";
	/* <S2>/Saturation2 */
	this.urlHashMap["adcs_sim_main:42:277:5:62"] = "MSP_BDOT.c:180,191";
	/* <S2>/Saturation3 */
	this.urlHashMap["adcs_sim_main:42:277:5:63"] = "MSP_BDOT.c:194,205";
	/* <S2>/To DigVal1 */
	this.urlHashMap["adcs_sim_main:42:277:5:17"] = "MSP_BDOT.c:147,181";
	/* <S2>/To DigVal2 */
	this.urlHashMap["adcs_sim_main:42:277:5:65"] = "MSP_BDOT.c:148,195";
	/* <S2>/To DigVal3 */
	this.urlHashMap["adcs_sim_main:42:277:5:66"] = "MSP_BDOT.c:149";
	/* <S2>/Unit Delay */
	this.urlHashMap["adcs_sim_main:42:277:5:45"] = "MSP_BDOT.c:123,266,286,306&MSP_BDOT.h:46";
	/* <S2>/gain matrix */
	this.urlHashMap["adcs_sim_main:42:277:5:64"] = "MSP_BDOT.c:157&MSP_BDOT.h:62&MSP_BDOT_data.c:27";
	/* <S3>/Data Type
Duplicate */
	this.urlHashMap["adcs_sim_main:42:277:5:41:2"] = "msg=rtwMsg_SimulationReducedBlock&block=adcs_sim_main:42:277:5:41:2";
	/* <S3>/Diff */
	this.urlHashMap["adcs_sim_main:42:277:5:41:3"] = "MSP_BDOT.c:122,126";
	/* <S3>/TSamp */
	this.urlHashMap["adcs_sim_main:42:277:5:41:4"] = "MSP_BDOT.c:107,110";
	/* <S3>/UD */
	this.urlHashMap["adcs_sim_main:42:277:5:41:5"] = "MSP_BDOT.c:124,130,276,280,296,300,316,320&MSP_BDOT.h:48";
	/* <S4>/Constant */
	this.urlHashMap["adcs_sim_main:42:277:5:54"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=adcs_sim_main:42:277:5:54";
	/* <S4>/Constant1 */
	this.urlHashMap["adcs_sim_main:42:277:5:56"] = "MSP_BDOT.c:258&MSP_BDOT.h:67&MSP_BDOT_data.c:32";
	/* <S4>/Product */
	this.urlHashMap["adcs_sim_main:42:277:5:55"] = "MSP_BDOT.c:257";
	/* <S4>/Sum */
	this.urlHashMap["adcs_sim_main:42:277:5:53"] = "MSP_BDOT.c:259";
	this.getUrlHash = function(sid) { return this.urlHashMap[sid];}
}
RTW_Sid2UrlHash.instance = new RTW_Sid2UrlHash();
function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "MSP_BDOT"};
	this.sidHashMap["MSP_BDOT"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<S1>"] = {sid: "adcs_sim_main:42:277"};
	this.sidHashMap["adcs_sim_main:42:277"] = {rtwname: "<S1>"};
	this.rtwnameHashMap["<S2>"] = {sid: "adcs_sim_main:42:277:5"};
	this.sidHashMap["adcs_sim_main:42:277:5"] = {rtwname: "<S2>"};
	this.rtwnameHashMap["<S3>"] = {sid: "adcs_sim_main:42:277:5:41"};
	this.sidHashMap["adcs_sim_main:42:277:5:41"] = {rtwname: "<S3>"};
	this.rtwnameHashMap["<S4>"] = {sid: "adcs_sim_main:42:277:5:50"};
	this.sidHashMap["adcs_sim_main:42:277:5:50"] = {rtwname: "<S4>"};
	this.rtwnameHashMap["<S1>/mag_body_T_unprocessed"] = {sid: "adcs_sim_main:42:277:2"};
	this.sidHashMap["adcs_sim_main:42:277:2"] = {rtwname: "<S1>/mag_body_T_unprocessed"};
	this.rtwnameHashMap["<S1>/Demux"] = {sid: "adcs_sim_main:42:277:4"};
	this.sidHashMap["adcs_sim_main:42:277:4"] = {rtwname: "<S1>/Demux"};
	this.rtwnameHashMap["<S1>/Pulse Generator"] = {sid: "adcs_sim_main:42:277:6"};
	this.sidHashMap["adcs_sim_main:42:277:6"] = {rtwname: "<S1>/Pulse Generator"};
	this.rtwnameHashMap["<S1>/bdot_controller_lib"] = {sid: "adcs_sim_main:42:277:5"};
	this.sidHashMap["adcs_sim_main:42:277:5"] = {rtwname: "<S1>/bdot_controller_lib"};
	this.rtwnameHashMap["<S1>/cmd_MAG_bdot"] = {sid: "adcs_sim_main:42:277:3"};
	this.sidHashMap["adcs_sim_main:42:277:3"] = {rtwname: "<S1>/cmd_MAG_bdot"};
	this.rtwnameHashMap["<S2>/B_body_in_T"] = {sid: "adcs_sim_main:42:277:5:22"};
	this.sidHashMap["adcs_sim_main:42:277:5:22"] = {rtwname: "<S2>/B_body_in_T"};
	this.rtwnameHashMap["<S2>/B_meas_valid"] = {sid: "adcs_sim_main:42:277:5:25"};
	this.sidHashMap["adcs_sim_main:42:277:5:25"] = {rtwname: "<S2>/B_meas_valid"};
	this.rtwnameHashMap["<S2>/MT_on"] = {sid: "adcs_sim_main:42:277:5:27"};
	this.sidHashMap["adcs_sim_main:42:277:5:27"] = {rtwname: "<S2>/MT_on"};
	this.rtwnameHashMap["<S2>/Constant"] = {sid: "adcs_sim_main:42:277:5:47"};
	this.sidHashMap["adcs_sim_main:42:277:5:47"] = {rtwname: "<S2>/Constant"};
	this.rtwnameHashMap["<S2>/Data Type Conversion"] = {sid: "adcs_sim_main:42:277:5:80"};
	this.sidHashMap["adcs_sim_main:42:277:5:80"] = {rtwname: "<S2>/Data Type Conversion"};
	this.rtwnameHashMap["<S2>/Demux"] = {sid: "adcs_sim_main:42:277:5:58"};
	this.sidHashMap["adcs_sim_main:42:277:5:58"] = {rtwname: "<S2>/Demux"};
	this.rtwnameHashMap["<S2>/Discrete Transfer Fcn"] = {sid: "adcs_sim_main:42:277:5:32"};
	this.sidHashMap["adcs_sim_main:42:277:5:32"] = {rtwname: "<S2>/Discrete Transfer Fcn"};
	this.rtwnameHashMap["<S2>/Discrete Derivative"] = {sid: "adcs_sim_main:42:277:5:41"};
	this.sidHashMap["adcs_sim_main:42:277:5:41"] = {rtwname: "<S2>/Discrete Derivative"};
	this.rtwnameHashMap["<S2>/Logical Operator"] = {sid: "adcs_sim_main:42:277:5:28"};
	this.sidHashMap["adcs_sim_main:42:277:5:28"] = {rtwname: "<S2>/Logical Operator"};
	this.rtwnameHashMap["<S2>/Logical Operator1"] = {sid: "adcs_sim_main:42:277:5:42"};
	this.sidHashMap["adcs_sim_main:42:277:5:42"] = {rtwname: "<S2>/Logical Operator1"};
	this.rtwnameHashMap["<S2>/Multiport Switch1"] = {sid: "adcs_sim_main:42:277:5:33"};
	this.sidHashMap["adcs_sim_main:42:277:5:33"] = {rtwname: "<S2>/Multiport Switch1"};
	this.rtwnameHashMap["<S2>/Multiport Switch2"] = {sid: "adcs_sim_main:42:277:5:46"};
	this.sidHashMap["adcs_sim_main:42:277:5:46"] = {rtwname: "<S2>/Multiport Switch2"};
	this.rtwnameHashMap["<S2>/Mux"] = {sid: "adcs_sim_main:42:277:5:59"};
	this.sidHashMap["adcs_sim_main:42:277:5:59"] = {rtwname: "<S2>/Mux"};
	this.rtwnameHashMap["<S2>/Product"] = {sid: "adcs_sim_main:42:277:5:60"};
	this.sidHashMap["adcs_sim_main:42:277:5:60"] = {rtwname: "<S2>/Product"};
	this.rtwnameHashMap["<S2>/Rate Transition1"] = {sid: "adcs_sim_main:42:277:5:6"};
	this.sidHashMap["adcs_sim_main:42:277:5:6"] = {rtwname: "<S2>/Rate Transition1"};
	this.rtwnameHashMap["<S2>/Rate Transition2"] = {sid: "adcs_sim_main:42:277:5:29"};
	this.sidHashMap["adcs_sim_main:42:277:5:29"] = {rtwname: "<S2>/Rate Transition2"};
	this.rtwnameHashMap["<S2>/Rate Transition3"] = {sid: "adcs_sim_main:42:277:5:30"};
	this.sidHashMap["adcs_sim_main:42:277:5:30"] = {rtwname: "<S2>/Rate Transition3"};
	this.rtwnameHashMap["<S2>/Rate Transition4"] = {sid: "adcs_sim_main:42:277:5:7"};
	this.sidHashMap["adcs_sim_main:42:277:5:7"] = {rtwname: "<S2>/Rate Transition4"};
	this.rtwnameHashMap["<S2>/Saturation1"] = {sid: "adcs_sim_main:42:277:5:61"};
	this.sidHashMap["adcs_sim_main:42:277:5:61"] = {rtwname: "<S2>/Saturation1"};
	this.rtwnameHashMap["<S2>/Saturation2"] = {sid: "adcs_sim_main:42:277:5:62"};
	this.sidHashMap["adcs_sim_main:42:277:5:62"] = {rtwname: "<S2>/Saturation2"};
	this.rtwnameHashMap["<S2>/Saturation3"] = {sid: "adcs_sim_main:42:277:5:63"};
	this.sidHashMap["adcs_sim_main:42:277:5:63"] = {rtwname: "<S2>/Saturation3"};
	this.rtwnameHashMap["<S2>/Signal Processing"] = {sid: "adcs_sim_main:42:277:5:50"};
	this.sidHashMap["adcs_sim_main:42:277:5:50"] = {rtwname: "<S2>/Signal Processing"};
	this.rtwnameHashMap["<S2>/To DigVal1"] = {sid: "adcs_sim_main:42:277:5:17"};
	this.sidHashMap["adcs_sim_main:42:277:5:17"] = {rtwname: "<S2>/To DigVal1"};
	this.rtwnameHashMap["<S2>/To DigVal2"] = {sid: "adcs_sim_main:42:277:5:65"};
	this.sidHashMap["adcs_sim_main:42:277:5:65"] = {rtwname: "<S2>/To DigVal2"};
	this.rtwnameHashMap["<S2>/To DigVal3"] = {sid: "adcs_sim_main:42:277:5:66"};
	this.sidHashMap["adcs_sim_main:42:277:5:66"] = {rtwname: "<S2>/To DigVal3"};
	this.rtwnameHashMap["<S2>/Unit Delay"] = {sid: "adcs_sim_main:42:277:5:45"};
	this.sidHashMap["adcs_sim_main:42:277:5:45"] = {rtwname: "<S2>/Unit Delay"};
	this.rtwnameHashMap["<S2>/gain matrix"] = {sid: "adcs_sim_main:42:277:5:64"};
	this.sidHashMap["adcs_sim_main:42:277:5:64"] = {rtwname: "<S2>/gain matrix"};
	this.rtwnameHashMap["<S2>/Dig_val"] = {sid: "adcs_sim_main:42:277:5:23"};
	this.sidHashMap["adcs_sim_main:42:277:5:23"] = {rtwname: "<S2>/Dig_val"};
	this.rtwnameHashMap["<S3>/U"] = {sid: "adcs_sim_main:42:277:5:41:1"};
	this.sidHashMap["adcs_sim_main:42:277:5:41:1"] = {rtwname: "<S3>/U"};
	this.rtwnameHashMap["<S3>/Data Type Duplicate"] = {sid: "adcs_sim_main:42:277:5:41:2"};
	this.sidHashMap["adcs_sim_main:42:277:5:41:2"] = {rtwname: "<S3>/Data Type Duplicate"};
	this.rtwnameHashMap["<S3>/Diff"] = {sid: "adcs_sim_main:42:277:5:41:3"};
	this.sidHashMap["adcs_sim_main:42:277:5:41:3"] = {rtwname: "<S3>/Diff"};
	this.rtwnameHashMap["<S3>/TSamp"] = {sid: "adcs_sim_main:42:277:5:41:4"};
	this.sidHashMap["adcs_sim_main:42:277:5:41:4"] = {rtwname: "<S3>/TSamp"};
	this.rtwnameHashMap["<S3>/UD"] = {sid: "adcs_sim_main:42:277:5:41:5"};
	this.sidHashMap["adcs_sim_main:42:277:5:41:5"] = {rtwname: "<S3>/UD"};
	this.rtwnameHashMap["<S3>/Y"] = {sid: "adcs_sim_main:42:277:5:41:6"};
	this.sidHashMap["adcs_sim_main:42:277:5:41:6"] = {rtwname: "<S3>/Y"};
	this.rtwnameHashMap["<S4>/b_in_T"] = {sid: "adcs_sim_main:42:277:5:51"};
	this.sidHashMap["adcs_sim_main:42:277:5:51"] = {rtwname: "<S4>/b_in_T"};
	this.rtwnameHashMap["<S4>/Constant"] = {sid: "adcs_sim_main:42:277:5:54"};
	this.sidHashMap["adcs_sim_main:42:277:5:54"] = {rtwname: "<S4>/Constant"};
	this.rtwnameHashMap["<S4>/Constant1"] = {sid: "adcs_sim_main:42:277:5:56"};
	this.sidHashMap["adcs_sim_main:42:277:5:56"] = {rtwname: "<S4>/Constant1"};
	this.rtwnameHashMap["<S4>/Product"] = {sid: "adcs_sim_main:42:277:5:55"};
	this.sidHashMap["adcs_sim_main:42:277:5:55"] = {rtwname: "<S4>/Product"};
	this.rtwnameHashMap["<S4>/Sum"] = {sid: "adcs_sim_main:42:277:5:53"};
	this.sidHashMap["adcs_sim_main:42:277:5:53"] = {rtwname: "<S4>/Sum"};
	this.rtwnameHashMap["<S4>/b_out_T"] = {sid: "adcs_sim_main:42:277:5:52"};
	this.sidHashMap["adcs_sim_main:42:277:5:52"] = {rtwname: "<S4>/b_out_T"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
